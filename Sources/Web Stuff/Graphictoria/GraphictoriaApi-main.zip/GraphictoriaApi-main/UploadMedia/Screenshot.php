<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="/html/css/bootstrap.min.css?v=15"/>
		<title>Graphictoria</title>
		<style>
			body{
				background:url("/html/img/background4.png") no-repeat center center fixed;background-size:cover;overflow-x:hidden;
			}
		</style>
	</head>
	<body>
		<h2>Screenshot</h2>
		<p>You have taken a screenshot.</p>
	</body>
</html>