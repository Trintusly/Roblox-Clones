<!DOCTYPE html>
<html>
	<head>
		<title>Graphictoria</title>
		<link rel="stylesheet" href="http://xdiscuss.net/html/css/bootstrap.min.css?v=45"/>
		<link rel="stylesheet" href="http://xdiscuss.net/html/css/ripples.min.css?v=2">
		<link rel="stylesheet" href="http://xdiscuss.net/html/css/style.css?v=51"/>
		<link rel="stylesheet" href="http://xdiscuss.net/html/css/style3.css?v=40"/>
		<script src="http://xdiscuss.net/html/js/jquery.js"></script>
	</head>
	<body class="container">
		<h4 style="color:grey;">Welcome to Graphictoria!</h4>
		<p><b>If you want to build</b>, create a new document and start building!<br>
		<b>If you are here to host a server</b>, create a new document and run the command you've been given.</p>
	</body>
</html>