### Graphictoria API
API that powered Graphictoria. Not so pretty code. Also not an IP logger as people claimed, but oh well.
