### Graphictoria Website
This is what used to be Graphictoria 4's website. Keep in mind that the code is quite disgusting. This in no way represents how I develop websites nowadays.
