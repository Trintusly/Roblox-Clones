<script src="/core/func/js/auth/login.js?v=3"></script>
<li style="padding-right:5px;">
	<input id="lUsername" class="form-control" style="height:23px;margin:5 5px;" type="text" placeholder="Username or Email">
	<input id="lPassword" class="form-control" style="height:23px" type="password" placeholder="Password">
</li>
<li>
	<button style="display:inline;" id="lSubmit" class="btn btn-success btn-xs">Login</button>
	<button style="display:inline;" id="lForgot" class="btn btn-primary btn-xs">Forgot Password</button>
	<p id="lStatus">Fill in the fields to login</p>
</li>