<?php
	class user {
		public static function filter($string) {
			$string = str_ireplace("FUCKING", "****", $string);
			$string = str_ireplace("GAY", "****", $string);
			$string = str_ireplace("RAPE", "****", $string);
			$string = str_ireplace("INCEST", "****", $string);
			$string = str_ireplace("BEASTIALITY", "****", $string);
			//$string = str_ireplace("CUM", "****", $string); do cum ent
			$string = str_ireplace("MAGGOT", "******", $string);
			$string = str_ireplace("BULLSHIT", "****", $string);
			$string = str_ireplace("FUCK", "****", $string);
			$string = str_ireplace("PENIS", "*****", $string);
			$string = str_ireplace("DICK", "*****", $string);
			$string = str_ireplace("VAGINA", "******", $string);
			$string = str_ireplace("VAG", "****", $string);
			$string = str_ireplace("FAGGOT", "*****", $string);
			$string = str_ireplace("FAG", "*****", $string);
			$string = str_ireplace("NIGGER", "*****", $string);
			$string = str_ireplace("ASSHOLE", "*****", $string);
			$string = str_ireplace("SHIT", "*****", $string);
			$string = str_ireplace("BITCH", "*****", $string);
			$string = str_ireplace("ANAL", "*****", $string);
			$string = str_ireplace("STFU", "*****", $string);
			$string = str_ireplace("CUNT", "*****", $string);
			$string = str_ireplace("PUSSY", "****", $string);
			$string = str_ireplace("HUMP", "****", $string);
			$string = str_ireplace("MEATSPIN", "********", $string);
			$string = str_ireplace("REDTUBE", "*******", $string);
			$string = str_ireplace("PORN", "****", $string);
			$string = str_ireplace("KYS", "***", $string);
			$string = str_ireplace("XVIDEOS", "*******", $string);
			$string = str_ireplace("HENTAI", "******", $string);
			$string = str_ireplace("GANGBANG", "********", $string);
			$string = str_ireplace("MILF", "****", $string);
			$string = str_ireplace("N*", "**", $string);
			$string = str_ireplace("WHORE", "*****", $string);
			$string = str_ireplace("WTF", "***", $string);
			$string = str_ireplace("HORNY", "*****", $string);
			$string = str_ireplace("TITS", "****", $string);
			$string = str_ireplace("RAPING", "******", $string);
			$string = str_ireplace("SEX", "***", $string);
			$string = str_ireplace("BOOB", "***", $string);
			$string = str_ireplace("NIGGA", "*****", $string);
			$string = str_ireplace("NLGGA", "*****", $string);
			$string = str_ireplace("gt2008.cf", "*********", $string);
			$string = str_ireplace("COCK", "****", $string);
			$string = str_ireplace("DICC", "****", $string);
			$string = str_ireplace("IDIOT", "*****", $string);
			$string = str_ireplace("NUDE", "****", $string);
			$string = str_ireplace("KESNER", "******", $string);
			$string = str_ireplace("NOBE", "****", $string);
			$string = str_ireplace("DIEMAUER", "********", $string);
			$string = str_ireplace("OTORIUM", "*******", $string);
			$string = str_ireplace("BRICKOPOLIS", "***********", $string);
			return $string;
		}
	}
?>