### Graphictoria Protocol
Used for machines that can not use GraphictoiaClientxxxx:// links. This enables them.
