<!DOCTYPE html>

<html>
  <head>
    <title>Bopimo! Maintenance</title>
	<script>
	window.location = "/"
	</script>
    <style>
      @font-face {
        src: url(/fonts/Ubahn.ttf);
        font-family: ubahn;
      }
      body {
        background-color: #7660E4;
        display: inline-block;
        margin auto;
        font-family: ubahn;
        color:white;
        font-size:50px;
      }
      div {
        height: 200px;
        width: 400px;
        text-align:center;
        position: fixed;
        top: 50%;
        left: 50%;
        margin-top: -100px;
        margin-left: -200px;
    }
    </style>
  </head>
  <body>

      <div>We're currently building Bopimo! Stay tuned!</div>

  </body>
</html>
