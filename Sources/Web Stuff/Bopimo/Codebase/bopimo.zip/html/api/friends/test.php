<?php 

require("friends.php");
//$friends->friendRequest( 3, $_SESSION["id"], "0" );