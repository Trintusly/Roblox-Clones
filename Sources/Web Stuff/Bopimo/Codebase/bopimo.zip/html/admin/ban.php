<?php
if(!isset($_POST['req']))
{
  ?>
  <form method="POST">
    <div class="col-9-12">
        <input type="number" placeholder="User ID" style="width:100%">
    </div>
    <div class="col-3-12">

    </div>
  </form>
  <?php
}

?>
