module.exports = {
    get all() {
        return require('./all');
    }
};
