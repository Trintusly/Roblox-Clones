module.exports = {
    get normalize() {
        return require('./normalize');
    }
};
